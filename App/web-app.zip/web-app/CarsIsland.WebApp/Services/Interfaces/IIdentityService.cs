﻿namespace CarsIsland.WebApp.Services.Interfaces
{
    public interface IIdentityService
    {
        bool IsUserAuthenticated();
    }
}
